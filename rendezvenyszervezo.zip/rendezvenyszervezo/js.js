
<script>
document.getElementById("menu-icon").addEventListener("click", function() {
    location.reload(); // újratölti az oldalt
});
</script>
