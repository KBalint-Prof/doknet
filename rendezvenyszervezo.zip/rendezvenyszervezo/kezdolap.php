
<?php
// Példa események tömb (később adatbázisból is jöhet)
$esemenyek = [
    [
        'cim' => 'Őszi bál',
        'datum' => '2025-11-15',
        'leiras' => 'A hagyományos őszi diákbál az iskolában. Zenés-táncos est minden diáknak.'
    ],
    [
        'cim' => 'Karácsonyi vásár',
        'datum' => '2025-12-10',
        'leiras' => 'Kézműves termékek, finomságok és ünnepi hangulat a tornateremben.'
    ],
    [
        'cim' => 'Tavaszi kirándulás',
        'datum' => '2026-04-20',
        'leiras' => 'Egynapos kirándulás a közeli természetvédelmi területre.'
    ],
];
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <title>Diákönkormányzati események</title>
    <link rel="stylesheet" href="style.css">
    <style>
        /* Alapstílus és háttér */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background: url('img/hatter.jpg') ;
            background-size: cover;
            
            line-height: 1.6;
            min-height: 100vh;
        }

    

        /* Tartalmi dobozok */
        header, main, footer {
            background-color: rgba(255, 255, 255, 0.85);
            margin: 20px auto;
            max-width: 900px;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.3);
            padding: 20px 30px;
        }

        /* Fejléc */
        .header-top-bar {
            display: flex;
            align-items: center;
            gap: 15px;
            margin-bottom: 15px;
        }

        .header-logo {
            width: 50px;
            height: auto;
            border-radius: 5px;
            cursor: pointer;
        }

        header h1 {
            flex: 1;
            text-align: center;
            color: #004080;
            font-weight: bold;
        }

        /* Navigáció */
        nav ul {
            list-style: none;
            padding: 0;
            margin: 15px 0 0 0;
            display: flex;
            justify-content: center;
            gap: 30px;
        }

        nav ul li a {
            text-decoration: none;
            color: #004080;
            font-weight: 600;
            padding: 8px 15px;
            border-radius: 5px;
            transition: background-color 0.3s ease, color 0.3s ease;
        }

        nav ul li a:hover,
        nav ul li a.active {
            background-color: #004080;
            color: white;
        }

        /* Fő tartalom */
        main h2 {
            border-bottom: 2px solid #004080;
            padding-bottom: 8px;
            margin-bottom: 20px;
        }

        /* Esemény kártyák */
        .esemeny-kartya {
            background-color: #fff;
            border-radius: 8px;
            padding: 15px 20px;
            margin-bottom: 20px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.1);
            transition: transform 0.3s ease;
        }

        .esemeny-kartya:hover {
            transform: translateY(-5px);
        }

        .esemeny-kartya h3 {
            color: #004080;
            margin-top: 0;
        }

        .datum {
            font-style: italic;
            color: #666;
            margin-bottom: 10px;
        }

        /* Lábléc */
        footer {
            text-align: center;
            font-size: 0.9em;
            color: #004080;
            margin-top: 30px;
        }

        /* Mobilbarát nézet */
        @media (max-width: 600px) {
            nav ul {
                flex-direction: column;
                gap: 10px;
            }

            header, main, footer {
                margin: 10px 15px;
                padding: 15px 20px;
            }

            .header-top-bar {
                flex-direction: column;
            }

            header h1 {
                text-align: center;
            }
        }
    </style>
</head>
<body>
    <header>
        <div class="header-top-bar">
            <img src="img/menucion.jpg" alt="Menü ikon" class="header-logo" id="menu-icon">
            <h1>Iskolai Diákönkormányzat</h1>
        </div>
        <nav>
            <ul>
                <li><a href="index.php" class="active">Főoldal</a></li>
                <li><a href="#">Események</a></li>
                <li><a href="regisztracio.php">Regisztráció</a></li>
                <li><a href="#">Kapcsolat</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <h2>Közelgő események</h2>
        <div class="esemenyek-lista">
            <?php foreach ($esemenyek as $esemeny): ?>
                <div class="esemeny-kartya">
                    <h3><?= htmlspecialchars($esemeny['cim']) ?></h3>
                    <p class="datum"><?= date('Y. m. d.', strtotime($esemeny['datum'])) ?></p>
                    <p><?= htmlspecialchars($esemeny['leiras']) ?></p>
                </div>
            <?php endforeach; ?>
        </div>
    </main>

    <footer>
        <p>© 2025 Iskolai Diákönkormányzat. Minden jog fenntartva.</p>
    </footer>

    <script>
        // Menü ikon kattintás – oldal újratöltése
        document.getElementById("menu-icon").addEventListener("click", function() {
            location.reload();
        });
    </script>
</body>
</html>
