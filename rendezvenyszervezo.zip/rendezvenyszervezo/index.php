
<?php
$esemenyek = [
    ['cim'=>'Őszi bál','datum'=>'2025-11-15','leiras'=>'A hagyományos őszi diákbál az iskolában. Zenés-táncos est minden diáknak.'],
    ['cim'=>'Karácsonyi vásár','datum'=>'2025-12-10','leiras'=>'Kézműves termékek, finomságok és ünnepi hangulat a tornateremben.'],
    ['cim'=>'Tavaszi kirándulás','datum'=>'2026-04-20','leiras'=>'Egynapos kirándulás a közeli természetvédelmi területre.'],
];
?>
<!DOCTYPE html>
<html lang="hu">
<head>
<meta charset="UTF-8">
<title>Diákönkormányzati események</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
    body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 0;
        background: url('img/hatter.jpg') no-repeat center center fixed;
        background-size: cover;
        line-height: 1.6;
        min-height: 100vh;
    }

    /* Tartalmi dobozok (most áttetsző fehér nélkül) */
    header, main, footer {
        max-width: 1200px;
        margin: 20px auto;
        padding: 20px 30px;
        border-radius: 10px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.3);
        background-color: transparent; /* fehér háttér eltávolítva */
    }

    /* Teljes szélességű fejléc */
    header {
       
    }

    .header-container {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 0 30px;
        gap: 20px;
    }

    .header-logo {
        width: 100px;
        height: auto;
        cursor: pointer;
    }

    header h1 {
        flex:1;
        text-align: center;
        color: #fff; /* Fehér szöveg jobban látszik a háttéren */
        font-weight: bold;
        margin:0;
        text-shadow: 1px 1px 3px rgba(0,0,0,0.6); /* Szöveg kiemelés */
    }

    nav ul {
        list-style: none;
        padding:0;
        margin:0;
        display:flex;
        gap:20px;
    }

    nav ul li a {
        text-decoration: none;
        color: #fff;
        font-weight:600;
        padding:8px 15px;
        border-radius:5px;
        transition: background-color 0.3s ease, color 0.3s ease;
        text-shadow: 1px 1px 2px rgba(0,0,0,0.5);
    }

    nav ul li a:hover,
    nav ul li a.active {
        background-color: rgba(0,64,128,0.8);
        color:white;
    }

    main h2 {
        border-bottom: 2px solid #fff;
        padding-bottom:8px;
        margin-bottom:20px;
        color: #fff;
        text-shadow: 1px 1px 2px rgba(0,0,0,0.6);
    }

    .esemeny-kartya {
        background-color: rgba(255,255,255,0.85); /* kártyák olvashatósága megmarad */
        border-radius: 8px;
        padding: 15px 20px;
        margin-bottom: 20px;
        box-shadow: 0 3px 10px rgba(0,0,0,0.1);
        transition: transform 0.3s ease;
    }

    .esemeny-kartya:hover { transform: translateY(-5px); }
    .esemeny-kartya h3 { color:#004080; margin-top:0; }
    .datum { font-style: italic; color:#666; margin-bottom:10px; }

    footer p {
        text-align:center;
        font-size:0.9em;
        color:#fff;
        text-shadow: 1px 1px 3px rgba(0,0,0,0.6);
    }

    @media (max-width:800px){
        .header-container { flex-direction: column; text-align:center; gap:10px; }
        nav ul { flex-direction: column; gap:10px; }
    }
</style>
</head>
<body>
<header>
    <div class="header-container">
        <img src="img/doklogo2.png" class="header-logo" id="menu-icon" alt="Menü ikon">
        <h1>Iskolai Diákönkormányzat</h1>
        <nav>
            <ul>
                <li><a href="index.php" class="active">Főoldal</a></li>
                <li><a href="#">Események</a></li>
                <li><a href="regisztracio.php">Regisztráció</a></li>
                <li><a href="#">Kapcsolat</a></li>
            </ul>
        </nav>
    </div>
</header>

<main>
    <h2>Közelgő események</h2>
    <div class="esemenyek-lista">
        <?php foreach($esemenyek as $e): ?>
            <div class="esemeny-kartya">
                <h3><?= htmlspecialchars($e['cim']) ?></h3>
                <p class="datum"><?= date('Y. m. d.', strtotime($e['datum'])) ?></p>
                <p><?= htmlspecialchars($e['leiras']) ?></p>
            </div>
        <?php endforeach; ?>
    </div>
</main>

<footer>
    <p>© 2025 Iskolai Diákönkormányzat. Minden jog fenntartva.</p>
</footer>

<script>
document.getElementById("menu-icon").addEventListener("click", function(){
    location.reload();
});
</script>
</body>
</html>
